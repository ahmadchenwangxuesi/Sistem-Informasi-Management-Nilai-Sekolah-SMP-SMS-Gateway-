<div class="block-flat">
	<div class="header">							
		<h3>Create Mata Pelajaran</h3>
	</div>
	<div class="content">
		<form role="form" method="POST"> 
			<div class="form-group"> 
				<label>Nama Mata Pelajaran</label> <input type="text" placeholder="Enter Mata Pelajaran" class="form-control" name="nama" required>
			</div>
			<button class="btn btn-primary" type="submit" name="create-pelajaran"><span class="fa fa-plus"></span> Tambah Mata Pelajaran</button>
		</form>
	</div>
</div>