<div class="block-flat">
	<div class="header">							
		<h3>Create Kelas</h3>
	</div>
	<div class="content">
		<form role="form" method="POST"> 
			<div class="form-group"> 
				<label>Nama  Kelas</label> <input type="text" placeholder="Enter Kelas" class="form-control" name="nama" required>
			</div>
			<button class="btn btn-primary" type="submit" name="create-kelas"><span class="fa fa-plus"></span> Tambah  Kelas</button>
		</form>
	</div>
</div>