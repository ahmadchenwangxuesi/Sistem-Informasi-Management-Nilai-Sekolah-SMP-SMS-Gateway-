<div class="block-flat">
	<div class="header">							
		<h3>Create Tahun Ajaran</h3>
	</div>
	<div class="content">
		<form role="form" method="POST"> 
			<div class="form-group"> 
				<label>Tahun Ajaran</label> <input type="text" placeholder="Enter Tahun Ajaran" class="form-control" name="nama" required>
			</div>
			<button class="btn btn-primary" type="submit" name="create-tahun"><span class="fa fa-plus"></span> Tambah Tahun Ajaran</button>
		</form>
	</div>
</div>