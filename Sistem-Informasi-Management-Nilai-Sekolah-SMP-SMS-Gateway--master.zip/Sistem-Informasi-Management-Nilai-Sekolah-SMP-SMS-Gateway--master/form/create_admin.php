<div class="block-flat">
	<div class="header">							
		<h3>Create Admin</h3>
	</div>
	<div class="content">
		<form role="form" method="POST"> 
			<div class="form-group"> 
				<label>Nama</label> <input type="text" placeholder="Enter Nama" class="form-control" name="nama" required>
			</div> 
			<div class="form-group">
				<label>Username</label> <input type="text" placeholder="Enter Username" class="form-control" name="username" required>
			</div>
			<div class="form-group"> 
				<label>Password</label> <input type="password" placeholder="Enter Password" class="form-control" name="password" required>
			</div>
			<button class="btn btn-primary" type="submit" name="create-admin"><span class="fa fa-plus"></span> Tambah Admin</button>
		</form>
	</div>
</div>