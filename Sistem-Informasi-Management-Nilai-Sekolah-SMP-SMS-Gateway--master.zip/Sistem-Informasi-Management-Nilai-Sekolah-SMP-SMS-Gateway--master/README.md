# SIMNS
Sistem Informasi Management Nilai Siswa SMP (SMS Gateway - Gammu).

![1](https://cloud.githubusercontent.com/assets/12929878/9202758/a2d855e4-407d-11e5-8353-59e5481e9059.jpg)
![2](https://cloud.githubusercontent.com/assets/12929878/9202759/a2dd8136-407d-11e5-8439-13f200fda287.jpg)
![3](https://cloud.githubusercontent.com/assets/12929878/9202760/a2e63056-407d-11e5-944b-7a372232c937.jpg)
![4](https://cloud.githubusercontent.com/assets/12929878/9202761/a2ec8bc2-407d-11e5-91f4-6e90c193463d.jpg)
![5](https://cloud.githubusercontent.com/assets/12929878/9202762/a2f5366e-407d-11e5-8792-c60060813f2f.jpg)
![6](https://cloud.githubusercontent.com/assets/12929878/9202763/a2f7b376-407d-11e5-94e0-18bb4747c740.jpg)
![7](https://cloud.githubusercontent.com/assets/12929878/9202764/a311da80-407d-11e5-8ac0-64d90ffc2dc6.jpg)
